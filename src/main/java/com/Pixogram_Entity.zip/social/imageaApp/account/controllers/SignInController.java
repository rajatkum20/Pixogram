package com.social.imageaApp.account.controllers;


import org.springframework.stereotype.Controller;






@Controller
public class SignInController {
	
//	@Autowired	
//	private UserServImpl userServImpl;
	

  
//    @PostMapping("/login")
//    public ApiResponse Login(@RequestBody LoginUser loginUser){
//        return userServImpl.Login(loginUser);
//    }
//	 
	 
}
